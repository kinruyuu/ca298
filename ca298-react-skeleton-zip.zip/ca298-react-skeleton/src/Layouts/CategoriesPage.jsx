// CategoriesPage.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link as RouterLink } from 'react-router-dom';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemButton from '@mui/material/ListItemButton';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';

function CategoriesPage() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/category/')
      .then(response => {
        setCategories(response.data);
      })
      .catch(error => console.error('Error fetching categories:', error));
  }, []);

  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        Categories
      </Typography>
      <List>
        {categories.map(category => (
          <ListItem key={category.shortcode} disablePadding>
            <ListItemButton component={RouterLink} to={`/category/${category.shortcode}`}>
              <ListItemText primary={category.display_name} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Container>
  );
}

export default CategoriesPage;
