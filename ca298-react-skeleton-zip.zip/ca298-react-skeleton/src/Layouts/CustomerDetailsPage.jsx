// CustomerDetailsPage.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Container, Typography, List, ListItem, ListItemText, Divider } from '@mui/material';

function CustomerDetailsPage() {
    const { id } = useParams();
    const [customer, setCustomer] = useState(null);

    useEffect(() => {
        axios.get(`http://127.0.0.1:8000/api/customer/${id}/`)
            .then(response => {
                setCustomer(response.data);
            })
            .catch(error => console.error('Error fetching customer details:', error));
    }, [id]);

    return (
        <Container>
            {customer && (
                <>
                    <Typography variant="h4" gutterBottom>
                        Customer Details
                    </Typography>
                    <Typography variant="h6">{customer.name}</Typography>
                    <Typography>Email: {customer.email}</Typography>
                    <Typography>Address: {customer.address}</Typography>
                </>
            )}
        </Container>
    );
}

export default CustomerDetailsPage;
