// 404 page if user tries to access a page that does not exist
export default function FourOhFour(){
    return (
        <div>The page you are looking for does not exist</div>
    );
}