// HomePage.jsx
import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';

function HomePage() {
    return (
        <Container>
            <Typography variant="h2" component="h1" gutterBottom>
                Welcome to My Shop
            </Typography>
            <Typography variant="body1">
                Browse our wide selection of products across various categories.
            </Typography>
        </Container>
    );
}

export default HomePage;
