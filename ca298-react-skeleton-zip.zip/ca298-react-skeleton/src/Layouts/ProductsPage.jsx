// ProductsPage.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';

function ProductsPage() {
  const { shortcode } = useParams();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get(`http://127.0.0.1:8000/api/product/?category=${shortcode}`)
      .then(response => {
        setProducts(response.data);
      })
      .catch(error => console.error('Error fetching products:', error));
  }, [shortcode]);

  return (
    <Container>
      <Typography variant="h4" component="h2" gutterBottom>
        Products in {shortcode}
      </Typography>
      <List>
        {products.map(product => (
          <ListItem key={product.id} divider>
            <ListItemText primary={product.name} secondary={`Price: $${product.price}`} />
          </ListItem>
        ))}
      </List>
    </Container>
  );
}

export default ProductsPage;

