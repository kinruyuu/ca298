// OrdersPage.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Typography, Tab, Tabs, Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

function OrdersPage() {
    const [orders, setOrders] = useState([]);
    const [status, setStatus] = useState('O');

    const handleChange = (event, newValue) => {
        setStatus(newValue);
    };

    useEffect(() => {
        axios.get(`http://127.0.0.1:8000/api/order/?status=${status}`)
            .then(response => {
                setOrders(response.data);
            })
            .catch(error => console.error('Error fetching orders:', error));
    }, [status]);

    return (
        <Container>
            <Typography variant="h4" component="h1" gutterBottom>
                Orders by Status
            </Typography>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={status} onChange={handleChange} aria-label="order status tabs">
                    <Tab label="Ordered" value="O" />
                    <Tab label="Processing" value="P" />
                    <Tab label="Shipped" value="S" />
                    <Tab label="Delivered" value="D" />
                </Tabs>
            </Box>
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Order ID</TableCell>
                            <TableCell align="right">Date Ordered</TableCell>
                            <TableCell align="right">Customer ID</TableCell>
                            <TableCell align="right">Shipping Address</TableCell>
                            <TableCell align="right">Status</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {orders.map((order) => (
                            <TableRow key={order.url} hover>
                                <TableCell component="th" scope="row">
                                    <RouterLink to={`/orders/${order.url.split('/').slice(-2)[0]}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                                        {order.url.split('/').slice(-2)[0]}
                                    </RouterLink>
                                </TableCell>
                                <TableCell align="right">{order.date_ordered}</TableCell>
                                <TableCell align="right">{order.customer}</TableCell>
                                <TableCell align="right">{order.shipping_addr}</TableCell>
                                <TableCell align="right">{order.status}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Container>
    );
}

export default OrdersPage;
