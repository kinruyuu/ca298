// IndividualOrderPage.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Container, Typography, List, ListItem, ListItemText, Divider, Box } from '@mui/material';

function IndividualOrderPage() {
    const { id } = useParams();
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [items, setItems] = useState([]);
    const [totalPrice, setTotalPrice] = useState(0);

    useEffect(() => {
        const fetchOrder = async () => {
            try {
                const orderResponse = await axios.get(`http://127.0.0.1:8000/api/order/${id}/`);
                setOrder(orderResponse.data);

                const itemsResponse = await axios.get(`http://127.0.0.1:8000/api/orderitem/?order=${id}`);
                const itemsData = itemsResponse.data;

                let total = 0;
                const itemsWithDetails = await Promise.all(itemsData.map(async (item) => {
                    try {
                        const productResponse = await axios.get(item.product);
                        const unitPrice = Number(productResponse.data.price);
                        if (isNaN(unitPrice)) {
                            throw new Error('Invalid unit price');
                        }
                        total += unitPrice * item.quantity;
                        return {
                            ...item,
                            productName: productResponse.data.name,
                            unitPrice: unitPrice
                        };
                    } catch (error) {
                        console.error('Failed to fetch product details:', error);
                        return {
                            ...item,
                            productName: 'Unknown',
                            unitPrice: 0
                        };
                    }
                }));

                setItems(itemsWithDetails);
                setTotalPrice(total);
                setLoading(false);
            } catch (error) {
                setError(error);
                setLoading(false);
            }
        };

        fetchOrder();
    }, [id]);

    if (loading) {
        return <Typography variant="h4">Loading...</Typography>;
    }

    if (error) {
        return <Typography variant="h4">Error: {error.message}</Typography>;
    }

    if (!order) {
        return <Typography variant="h4">Order not found</Typography>;
    }

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                Order Details (ID: {id})
            </Typography>
            <Typography variant="subtitle1">Date Ordered: {new Date(order.date_ordered).toLocaleString()}</Typography>
            <Typography variant="subtitle1">Shipping Address: {order.shipping_addr}</Typography>
            <Typography variant="subtitle1">Status: {order.status}</Typography>
            <Divider sx={{ my: 2 }} />
            <List>
                {items.map((item, index) => (
                    <ListItem key={index}>
                        <ListItemText
                            primary={`${item.productName} x ${item.quantity}`}
                            secondary={`Price per item: $${item.unitPrice.toFixed(2)}`}
                        />
                    </ListItem>
                ))}
            </List>
            <Divider sx={{ my: 2 }} />
            <Box>
                <Typography variant="h6" component="span" sx={{ fontWeight: 'bold' }}>
                    Total Price:
                </Typography>
                <Typography variant="h6" component="span" sx={{ ml: 1 }}>
                    ${totalPrice.toFixed(2)}
                </Typography>
            </Box>
        </Container>
    );
}

export default IndividualOrderPage;
