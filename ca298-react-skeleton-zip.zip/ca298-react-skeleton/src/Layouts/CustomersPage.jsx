    // CustomersPage.js
    import React, { useState, useEffect } from 'react';
    import axios from 'axios';
    import { useNavigate } from 'react-router-dom';
    import { Container, List, ListItem, ListItemText, ListItemButton, Typography } from '@mui/material';

    function CustomersPage() {
        const [customers, setCustomers] = useState([]);
        const navigate = useNavigate();

        useEffect(() => {
            axios.get('http://127.0.0.1:8000/api/customer/')
                .then(response => {
                    setCustomers(response.data);
                })
                .catch(error => console.error('Error fetching customers:', error));
        }, []);

        const handleCustomerClick = (url) => {
            const customerId = url.split('/').filter(Boolean).pop(); // Extracts ID from URL
            navigate(`/customers/${customerId}`);
        };

        return (
            <Container>
                <Typography variant="h4" gutterBottom>
                    Customers
                </Typography>
                <List>
                    {customers.map((customer) => (
                        <ListItem key={customer.url} disablePadding>
                            <ListItemButton onClick={() => handleCustomerClick(customer.url)}>
                                <ListItemText primary={customer.name} secondary={customer.email} />
                            </ListItemButton>
                        </ListItem>
                    ))}
                </List>
            </Container>
        );
    }

    export default CustomersPage;
