// App.js
import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './Layouts/Navbar';
import HomePage from './Layouts/HomePage';
import CategoriesPage from './Layouts/CategoriesPage';
import ProductsPage from './Layouts/ProductsPage';
import OrdersPage from './Layouts/OrdersPage';
import CustomersPage from './Layouts/CustomersPage';
import CustomerDetailsPage from './Layouts/CustomerDetailsPage';
import IndividualOrderPage from './Layouts/IndividualOrderPage';
import FourOhFour from './Layouts/FourOhFour';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/categories" element={<CategoriesPage />} />
        <Route path="/category/:shortcode" element={<ProductsPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/customers" element={<CustomersPage />} />
        <Route path="/customers/:id" element={<CustomerDetailsPage />} />
        <Route path="/orders/:id" element={<IndividualOrderPage />} />
        <Route path="*" element={<FourOhFour />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
